-- MySQL dump 10.13  Distrib 5.7.9, for Win32 (AMD64)
--
-- Host: 127.0.0.1    Database: bditac
-- ------------------------------------------------------
-- Server version	5.7.11

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `crise_tipo_subtipo`
--

DROP TABLE IF EXISTS `crise_tipo_subtipo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `crise_tipo_subtipo` (
  `ctp_id` int(3) NOT NULL,
  `ctt_id` int(3) NOT NULL,
  `cts_id` int(3) NOT NULL,
  `ctg_id` int(3) NOT NULL,
  `ctc_id` int(3) NOT NULL,
  `ctp_descricao` varchar(150) DEFAULT NULL,
  PRIMARY KEY (`ctp_id`,`ctt_id`,`cts_id`,`ctg_id`,`ctc_id`),
  KEY `fk_crise_tipo_subtipo_crise_tipo_tipo1_idx` (`ctt_id`) USING BTREE,
  KEY `fk_tipo_subtipo_subgrupo_idx` (`cts_id`) USING BTREE,
  KEY `fk_tipo_subtipo_grupo_idx` (`ctg_id`) USING BTREE,
  KEY `fk_tipo_subtipo_classe_idx` (`ctc_id`) USING BTREE,
  CONSTRAINT `crise_tipo_subtipo_ibfk_1` FOREIGN KEY (`ctc_id`) REFERENCES `crise_tipo_classe` (`ctc_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `crise_tipo_subtipo_ibfk_2` FOREIGN KEY (`ctg_id`) REFERENCES `crise_tipo_grupo` (`ctg_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `crise_tipo_subtipo_ibfk_3` FOREIGN KEY (`cts_id`) REFERENCES `crise_tipo_subgrupo` (`cts_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `crise_tipo_subtipo_ibfk_4` FOREIGN KEY (`ctt_id`) REFERENCES `crise_tipo_tipo` (`ctt_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-06-14 23:04:16
